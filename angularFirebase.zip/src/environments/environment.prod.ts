export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyD4U9LPhY567ddRSbtu_wM1yeE05NKLhLo",
    authDomain: "prueba-inicial-85108.firebaseapp.com",
    projectId: "prueba-inicial-85108",
    storageBucket: "prueba-inicial-85108.appspot.com",
    messagingSenderId: "862343000772",
    appId: "1:862343000772:web:8075e0480e064bf971cf91",
    measurementId: "G-VWBDBSTWDW"
  }
};
